package TGI::MuSiC2::Complicated;

use strict;
use warnings FATAL => 'all';

sub print_stuff {
    print "Hi\n";
}

1;

