# Notes on testing

## Background reading

* [Useful set of slides](http://perl.plover.com/yak/testing/) - motivation and best practices
* [Testing tutorial](http://search.cpan.org/~rgarcia/perl-5.10.0/lib/Test/Tutorial.pod) - introductory stuff
* [Test reference card](https://github.com/statico/perl-test-refcard) - useful cheat sheet
* [Dr. Dobbs article about testing](http://www.drdobbs.com/web-development/automated-testing-with-the-perl-test-mod/184416061)
* [Test driven development](theory)


